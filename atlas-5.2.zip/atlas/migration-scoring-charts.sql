-- ===========================================================================
-- ATLAS 5.2 — migration-scoring-charts.sql
-- Prerequisite: migration-outcome-score.sql (5.1) must already be applied
-- (it creates assert_agency_access, which these functions use).
--
-- Adds the two RLS-safe aggregate functions the dashboard charts need:
--   monthly_score_series  — positive-ratio trend by month
--   agency_officer_scores — per-officer ranked score packages
-- SECURITY DEFINER; returns aggregates only, guarded by agency membership.
-- Idempotent.
-- ===========================================================================

-- Monthly positive-ratio series (last p_months calendar months, oldest first)
create or replace function monthly_score_series(p_agency_id uuid, p_months int default 8)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform assert_agency_access(p_agency_id);
  return coalesce((
    select jsonb_agg(row_obj order by month)
    from (
      select to_char(date_trunc('month', review_date), 'YYYY-MM') as month,
             jsonb_build_object(
               'month',    to_char(date_trunc('month', review_date), 'YYYY-MM'),
               'total',    count(*),
               'positive', count(*) filter (where follow_up_outcome in ('no_action','commendation')),
               'pct',      round(100.0 * count(*) filter (where follow_up_outcome in ('no_action','commendation'))
                                 / greatest(count(*), 1))
             ) as row_obj
        from bwc_reviews
       where agency_id = p_agency_id
         and status = 'approved'
         and review_date >= date_trunc('month', now()) - make_interval(months => greatest(p_months, 1) - 1)
       group by date_trunc('month', review_date)
    ) m
  ), '[]'::jsonb);
end $$;

-- Per-officer ranked score packages. p_officer_ids null = whole agency;
-- supply ids to scope (e.g. a supervisor's squad).
create or replace function agency_officer_scores(p_agency_id uuid, p_officer_ids uuid[] default null)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform assert_agency_access(p_agency_id);
  return coalesce((
    select jsonb_agg(row_obj order by (row_obj->>'pct')::numeric desc nulls last,
                                       row_obj->>'last_name')
    from (
      select jsonb_build_object(
               'officer_id',   o.id,
               'first_name',   o.first_name,
               'last_name',    o.last_name,
               'badge_number', o.badge_number,
               'total',        count(r.id),
               'positive',     count(r.id) filter (where r.follow_up_outcome in ('no_action','commendation')),
               'pct',          case when count(r.id) = 0 then null
                                    else round(100.0 * count(r.id) filter (where r.follow_up_outcome in ('no_action','commendation'))
                                          / count(r.id)) end,
               'distribution', jsonb_build_object(
                 'no_action',        count(r.id) filter (where r.follow_up_outcome = 'no_action'),
                 'commendation',     count(r.id) filter (where r.follow_up_outcome = 'commendation'),
                 'coaching',         count(r.id) filter (where r.follow_up_outcome = 'coaching'),
                 'training',         count(r.id) filter (where r.follow_up_outcome = 'training'),
                 'internal_affairs', count(r.id) filter (where r.follow_up_outcome = 'internal_affairs'),
                 'pip',              count(r.id) filter (where r.follow_up_outcome = 'pip'))
             ) as row_obj
        from personnel_roster o
        left join bwc_reviews r
               on r.primary_officer_id = o.id and r.status = 'approved'
       where o.agency_id = p_agency_id
         and (p_officer_ids is null or o.id = any(p_officer_ids))
       group by o.id, o.first_name, o.last_name, o.badge_number
    ) t
  ), '[]'::jsonb);
end $$;

grant execute on function monthly_score_series(uuid, int),
                          agency_officer_scores(uuid, uuid[]) to authenticated;

-- Sanity: both should return without error for the seeded agency
select monthly_score_series('a0000000-0000-0000-0000-000000000001'::uuid) is not null as monthly_ok,
       agency_officer_scores('a0000000-0000-0000-0000-000000000001'::uuid) is not null as officers_ok;
