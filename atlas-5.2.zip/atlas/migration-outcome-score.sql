-- ===========================================================================
-- ATLAS 5.1 — migration-outcome-score.sql
-- Switches the officer Performance Score from KPI-average to the canonical
-- OUTCOME-BASED positive ratio, and adds RLS-safe aggregate score functions.
--
--   Performance Score = round( (no_action + commendation) / total * 100 )
--
-- Run once in the Supabase SQL Editor. Idempotent (create or replace + full
-- recompute at the end). kpi_score on bwc_reviews is untouched — it remains
-- the per-review observation-frequency metric.
-- ===========================================================================

-- 1) Replace the trigger function: outcome ratio, whole number ---------------
create or replace function refresh_officer_score()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update personnel_roster p
     set performance_score = sub.score
    from (select round(
                   100.0 * count(*) filter (where follow_up_outcome in ('no_action','commendation'))
                   / greatest(count(*), 1)
                 ) as score
            from bwc_reviews
           where primary_officer_id = new.primary_officer_id
             and status = 'approved') sub
   where p.id = new.primary_officer_id;
  return new;
end $$;

-- Re-point the trigger at outcome changes (was: kpi_score changes)
drop trigger if exists trg_refresh_officer_score on bwc_reviews;
create trigger trg_refresh_officer_score
  after insert or update of follow_up_outcome, status on bwc_reviews
  for each row execute function refresh_officer_score();

-- 2) RLS-safe aggregate packages ---------------------------------------------
-- SECURITY DEFINER so supervisors (who cannot read other reviewers' rows)
-- still get correct agency-wide numbers. Returns ONLY aggregates — no row
-- data, no notes, no case numbers. Guard: caller must belong to the agency
-- or be super_admin.

create or replace function assert_agency_access(p_agency_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (is_super_admin() or get_my_agency_id() = p_agency_id) then
    raise exception 'access denied to agency %', p_agency_id;
  end if;
end $$;

-- Shared package builder over an arbitrary review filter
create or replace function build_score_package(p_agency_id uuid, p_officer_ids uuid[])
returns jsonb language sql security definer set search_path = public as $$
  with pool as (
    select follow_up_outcome
      from bwc_reviews
     where agency_id = p_agency_id
       and status = 'approved'
       and (p_officer_ids is null or primary_officer_id = any(p_officer_ids))
  ),
  agg as (
    select count(*)::int as total,
           count(*) filter (where follow_up_outcome in ('no_action','commendation'))::int as positive,
           jsonb_build_object(
             'no_action',        count(*) filter (where follow_up_outcome = 'no_action'),
             'commendation',     count(*) filter (where follow_up_outcome = 'commendation'),
             'coaching',         count(*) filter (where follow_up_outcome = 'coaching'),
             'training',         count(*) filter (where follow_up_outcome = 'training'),
             'internal_affairs', count(*) filter (where follow_up_outcome = 'internal_affairs'),
             'pip',              count(*) filter (where follow_up_outcome = 'pip')
           ) as dist
      from pool
  )
  select jsonb_build_object(
    'total_reviews',       total,
    'positive_reviews',    positive,
    'positive_percentage', case when total = 0 then null
                                else round(100.0 * positive / total) end,
    'distribution',        dist
  ) from agg;
$$;

-- Agency-wide score (all agency roles may call for their own agency)
create or replace function agency_score_package(p_agency_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform assert_agency_access(p_agency_id);
  return build_score_package(p_agency_id, null);
end $$;

-- Individual officer score
create or replace function officer_score_package(p_officer_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_agency uuid;
begin
  select agency_id into v_agency from personnel_roster where id = p_officer_id;
  if v_agency is null then raise exception 'officer not found'; end if;
  perform assert_agency_access(v_agency);
  return build_score_package(v_agency, array[p_officer_id]);
end $$;

-- Ad-hoc group score (all officers must belong to one agency the caller can access)
create or replace function group_score_package(p_officer_ids uuid[])
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_agencies uuid[];
begin
  if p_officer_ids is null or array_length(p_officer_ids, 1) is null then
    raise exception 'no officers supplied';
  end if;
  select array_agg(distinct agency_id) into v_agencies
    from personnel_roster where id = any(p_officer_ids);
  if v_agencies is null or array_length(v_agencies, 1) <> 1 then
    raise exception 'officers must belong to exactly one agency';
  end if;
  perform assert_agency_access(v_agencies[1]);
  return build_score_package(v_agencies[1], p_officer_ids);
end $$;

grant execute on function agency_score_package(uuid),
                          officer_score_package(uuid),
                          group_score_package(uuid[]),
                          assert_agency_access(uuid),
                          build_score_package(uuid, uuid[]) to authenticated;

-- 3) Recompute every officer's stored score under the new formula ------------
update personnel_roster p
   set performance_score = coalesce(sub.score, null)
  from (select primary_officer_id,
               round(100.0 * count(*) filter (where follow_up_outcome in ('no_action','commendation'))
                     / greatest(count(*), 1)) as score
          from bwc_reviews
         where status = 'approved'
         group by primary_officer_id) sub
 where p.id = sub.primary_officer_id;

-- Officers with no reviews yet: keep whatever seed value or set null? Seed gave
-- them illustrative scores; leave untouched so tiers/demo data still render.

-- 4) Acceptance check — synthetic vector, computed in SQL, no data written ---
with vector(follow_up) as (
  values ('no_action'),('no_action'),('commendation'),('training'),('coaching')
)
select count(*) as total_reviews,
       count(*) filter (where follow_up in ('no_action','commendation')) as positive_reviews,
       round(100.0 * count(*) filter (where follow_up in ('no_action','commendation')) / count(*)) as positive_percentage
from vector;
-- Expected: total_reviews=5, positive_reviews=3, positive_percentage=60
